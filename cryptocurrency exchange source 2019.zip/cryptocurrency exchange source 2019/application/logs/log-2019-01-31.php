<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-31 10:32:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tradeboxbdtask/public_html/tradebox-v5.3/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-01-31 10:32:26 --> Unable to connect to the database
