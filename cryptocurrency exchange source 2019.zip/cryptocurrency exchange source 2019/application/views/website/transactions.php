        <div class="ballance-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="table-bg">
                                        <th><?php echo display('sl_no') ?></th>
                                        <th><?php echo display('transection') ?></th>
                                        <th><?php echo display('amount') ?></th>
                                        <th><?php echo display('fees') ?></th>
                                        <th><?php echo display('crypto_dollar_currency') ?></th>
                                    </tr>
                                </thead>
                                <tbody>

                                <?php $i=1; foreach ($balance_log as $key => $value) { ?>
                                    <tr>
                                        <td><?php echo $i ?></td>
                                        <td><?php echo $value->transaction_type ?></td>
                                        <td><?php echo $value->transaction_amount ?></td>
                                        <td><?php echo $value->transaction_fees ?></td>
                                        <td><div class="d-flex marks-ico">
                                                <div><img src="<?php echo base_url($value->image) ?>" alt="<?php echo $value->currency_symbol ?>"></div>
                                                <div class="ico-name">
                                                    <font><?php echo $value->full_name ?></font>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php $i++; } ?>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>