        <div class="ballance-content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                    
                        <!-- alert message -->
                        <?php if ($this->session->flashdata('message') != null) {  ?>
                        <div class="alert alert-info alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <?php echo $this->session->flashdata('message'); ?>
                        </div> 
                        <?php } ?>
                            
                        <?php if ($this->session->flashdata('exception') != null) {  ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <?php echo $this->session->flashdata('exception'); ?>
                        </div>
                        <?php } ?>
                            
                        <?php if (validation_errors()) {  ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <?php echo validation_errors(); ?>
                        </div>
                        <?php } ?> 
                        <!-- /.end of alert message -->
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="table-bg">
                                        <th><?php echo display('cryptocoin') ?></th>
                                        <th><?php echo display('name') ?></th>
                                        <th><?php echo display('total_balance') ?></th>
                                        <th><?php echo display('available_balance') ?></th>
                                        <th colspan="2"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($coin_list as $coin_key => $coin_value) { ?>
                                <?php $balance = '0.00'; foreach ($balances as $key => $value) { 
                                    if ($value->currency_symbol== $coin_value->symbol) {
                                        $balance = $value->balance;

                                    }

                                 } ?>
                                    <tr>
                                        <td><div class="d-flex marks-ico">
                                                <div><img src="<?php echo base_url("$coin_value->image") ?>" alt=""></div>
                                                <div class="ico-name">
                                                    <font><?php echo $coin_value->symbol; ?></font>
                                                    <span class="text-muted">(<?php echo $coin_value->coin_name; ?>)</span>
                                                </div>
                                            </div></td>
                                        <td><?php echo $coin_value->coin_name; ?></td>
                                        <td><?php echo $balance; ?></td>
                                        <td><?php echo $balance; ?></td>
                                        <td><a href="<?php echo base_url("deposit/$coin_value->symbol"); ?>" class="btn btn-tread"><?php echo display('deposit'); ?></a></td>
                                        <td><a href="<?php echo base_url("withdraw/$coin_value->symbol"); ?>" class="btn btn-tread"><?php echo display('withdraw') ?></a></td>
                                    </tr>                                
                                <?php } ?>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>